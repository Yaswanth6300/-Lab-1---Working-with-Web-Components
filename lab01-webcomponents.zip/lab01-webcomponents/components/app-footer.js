// components/app-footer.js
class AppFooter extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        footer {
          display:grid;
          grid-template-columns: 1fr auto;
          align-items:center;
          gap: 1rem;
          padding: 1rem 1.25rem;
          border-top: 1px solid rgba(255,255,255,.08);
          background: linear-gradient(180deg, rgba(255,255,255,.02), rgba(255,255,255,.04));
        }
        .left, .right { color: #9ca3af; font-size:.95rem; }
        a { color: #a5b4fc; text-decoration: none; }
        ::slotted(a) { color: #a5b4fc; }
      </style>
      <footer>
        <div class="left"><slot name="left">Footer</slot></div>
        <div class="right"><slot name="right"></slot></div>
      </footer>
    `;
  }
}

customElements.define('app-footer', AppFooter);
