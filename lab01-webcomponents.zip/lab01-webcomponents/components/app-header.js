// components/app-header.js
class AppHeader extends HTMLElement {
  static get observedAttributes() { return ['title', 'subtitle']; }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        header {
          display:flex; align-items:center; justify-content:space-between;
          gap: 1rem; padding: 1rem 1.25rem;
          background: linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.02));
          border-bottom: 1px solid rgba(255,255,255,.08);
          position: sticky; top: 0; z-index: 10;
        }
        .titles { display:flex; flex-direction:column; }
        h1 { margin:0; font-size: clamp(1.05rem, 1.2rem + 0.5vw, 1.6rem); letter-spacing: .2px; }
        .sub { color: #9ca3af; font-size:.95rem; }
        .pill {
          display:inline-flex; align-items:center; gap:.4rem;
          font-size:.85rem; color:#e5e7eb; padding: .35rem .6rem;
          border:1px solid rgba(255,255,255,.12);
          border-radius: 999px;
          background: #0b1229;
        }
        .dot { width:8px; height:8px; border-radius:999px; background:#22d3ee; box-shadow:0 0 16px #22d3ee; }
      </style>
      <header>
        <div class="titles">
          <h1 id="title"></h1>
          <span id="subtitle" class="sub"></span>
        </div>
        <span class="pill"><span class="dot"></span> Web Components</span>
      </header>
    `;
  }

  connectedCallback() { this.#render(); }
  attributeChangedCallback() { this.#render(); }

  #render() {
    this.shadowRoot.getElementById('title').textContent = this.getAttribute('title') || 'App';
    this.shadowRoot.getElementById('subtitle').textContent = this.getAttribute('subtitle') || '';
  }
}

customElements.define('app-header', AppHeader);
