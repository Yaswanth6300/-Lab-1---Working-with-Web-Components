// components/user-card.js
class UserCard extends HTMLElement {
  static get observedAttributes() { return ['name', 'role', 'img-src']; }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        .card {
          background: #0b1229;
          border: 1px solid rgba(255,255,255,.12);
          border-radius: 14px;
          padding: .75rem;
          cursor: pointer;
          transition: transform .12s ease, border-color .12s ease, box-shadow .12s ease;
        }
        .card:hover {
          transform: translateY(-2px);
          border-color: rgba(96,165,250,.6);
          box-shadow: 0 6px 18px rgba(0,0,0,.25);
        }
        .row { display:flex; gap:.75rem; align-items:center; }
        img { width: 56px; height: 56px; border-radius: 10px; object-fit: cover; }
        .name { font-weight: 700; }
        .role { color: #9ca3af; font-size: .95rem; }
        .meta { display:block; margin-top:.5rem; color:#a5b4fc; font-size:.9rem; }
        ::slotted(*) { color:#9ca3af; font-size:.9rem; }
      </style>
      <div class="card" part="card" tabindex="0" role="button" aria-pressed="false">
        <div class="row">
          <img id="img" alt="" />
          <div>
            <div class="name" id="name"></div>
            <div class="role" id="role"></div>
          </div>
        </div>
        <slot name="meta"></slot>
      </div>
    `;
  }

  connectedCallback() {
    this.#render();
    const root = this.shadowRoot.querySelector('.card');
    root.addEventListener('click', () => this.#select());
    root.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.#select(); }
    });
  }

  attributeChangedCallback() { this.#render(); }

  #render() {
    const name = this.getAttribute('name') || 'User';
    const role = this.getAttribute('role') || 'Role';
    const img = this.getAttribute('img-src') || 'https://i.pravatar.cc/120';
    this.shadowRoot.getElementById('name').textContent = name;
    this.shadowRoot.getElementById('role').textContent = role;
    const imgEl = this.shadowRoot.getElementById('img');
    imgEl.src = img; imgEl.alt = name;
  }

  #select() {
    const detail = {
      name: this.getAttribute('name') || '',
      role: this.getAttribute('role') || '',
      imgSrc: this.getAttribute('img-src') || '',
      bio: this.querySelector('[slot="meta"]')?.textContent?.trim() || ''
    };
    this.dispatchEvent(new CustomEvent('user-select', {
      bubbles: true, composed: true, detail
    }));
  }
}

customElements.define('user-card', UserCard);
