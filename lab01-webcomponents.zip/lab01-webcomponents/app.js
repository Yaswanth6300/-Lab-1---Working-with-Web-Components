// app.js
import './components/app-header.js';
import './components/user-card.js';
import './components/app-footer.js';

/**
 * Render the page layout into #app
 * Header (full width)
 * Main: left = user cards, right = details
 * Footer (full width)
 */
const app = document.getElementById('app');

app.innerHTML = `
  <app-header title="Lab 01 • Web Components" subtitle="Cohesion, OCP, & Usability in practice"></app-header>
  <main class="main-grid">
    <section class="panel">
      <h2 class="section-title"><span class="dot"></span> Team</h2>
      <div class="cards" id="cards"></div>
    </section>
    <aside class="panel" id="details">
      <h2 class="section-title"><span class="dot"></span> Details</h2>
      <p class="muted">Select a user to see more details.</p>
    </aside>
  </main>
  <app-footer>
    <span slot="left">Contact: ui-lab@example.edu</span>
    <span slot="right">© 2025 UI Lab · <a href="#" rel="noreferrer">Accessibility</a></span>
  </app-footer>
`;

// Sample data (could come from API in a real app)
const USERS = [
  { name: 'Alice', role: 'Designer', imgSrc: 'https://i.pravatar.cc/120?img=5', bio: 'Focus: design systems, accessibility, prototypes.' },
  { name: 'Bob', role: 'Engineer', imgSrc: 'https://i.pravatar.cc/120?img=12', bio: 'Focus: web components, performance, testing.' },
  { name: 'Carlos', role: 'PM', imgSrc: 'https://i.pravatar.cc/120?img=25', bio: 'Focus: requirements, roadmap, delivery.' },
];

const cardsEl = document.getElementById('cards');
const detailsEl = document.getElementById('details');

// Render user-card components (Open/Closed Principle: configured via attributes/slots)
USERS.forEach(u => {
  const card = document.createElement('user-card');
  card.setAttribute('name', u.name);
  card.setAttribute('role', u.role);
  card.setAttribute('img-src', u.imgSrc);
  card.innerHTML = `<span slot="meta" class="muted">${u.bio}</span>`;
  cardsEl.appendChild(card);
});

// Controller logic (separation of concerns): listen to selection events from user-card
cardsEl.addEventListener('user-select', (ev) => {
  const { name, role, imgSrc, bio } = ev.detail;
  detailsEl.innerHTML = `
    <h2 class="section-title"><span class="dot"></span> Details</h2>
    <div style="display:flex; gap:1rem; align-items:center; margin:.5rem 0 1rem 0;">
      <img src="\${imgSrc}" alt="\${name}" width="72" height="72" style="border-radius:12px; border:1px solid rgba(255,255,255,.15)" />
      <div>
        <div style="font-weight:700; font-size:1.1rem">\${name}</div>
        <div class="muted">\${role}</div>
      </div>
    </div>
    <p>\${bio}</p>
    <p class="muted">Demonstrates <strong>Cohesion</strong> (each component has a single purpose),
    <strong>Open/Closed</strong> (config via attributes/slots), and low <strong>Coupling</strong>
    (cards emit events; controller updates details).</p>
  `;
});
